# Help-Desk-Ticketing-System
A simple help dek ticketing system for fault reporting in JavaScript
